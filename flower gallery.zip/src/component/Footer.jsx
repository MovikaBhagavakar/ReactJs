import React from "react";
import './css/footer.css'

export default function Footer(){
    return <>
    <div className="wel">
    <h1 >Thank You For visiting</h1>
    </div>
        </>
    
}