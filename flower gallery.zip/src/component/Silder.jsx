import React from "react";
import img1 from "./Image/R.png"
import img2 from "./Image/bg1.webp"
import img3 from "./Image/bg4.png"
import img4 from "./Image/bg3.png"
import img5 from "./Image/bg5.webp"
import img6 from "./Image/bg6.png"
import img7 from "./Image/bg7.png"
import './css/slid.css'


 function Silder(){
    return <>
    
    
    <div id="carouselExample" className="carousel slide">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src={img1} className="d-block  silde" alt="..."/>
      <h1 className="Red"> Red Rose</h1>
    </div>
    <div className="carousel-item">
      <img src={img2} className="d-block  silde" alt="..."/>
      <h1 className="Red1">Rose</h1>
    </div>
     <div className="carousel-item">
      <img src={img3} className="d-block  silde" alt="..."/>
      <h1 className="flow">FLowers</h1>
    </div>
    <div className="carousel-item">
      <img src={img4} className="d-block  silde" alt="..."/>
      <h1 className="louts">Louts</h1>
    </div>
    <div className="carousel-item">
      <img src={img5} className="d-block  silde" alt="..."/>
      <h1 className="louts1">Pink flower</h1>
    </div> 
    <div className="carousel-item">
      <img src={img6} className="d-block  silde" alt="..."/>
      <h1 className="blue1">blue flower</h1>
    </div> 
    <div className="carousel-item">
      <img src={img7} className="d-block  silde" alt="..."/>
      <h1 className="orange1">orange flower</h1>
    </div> 
  </div>
  <div className="btn">
  <button className="carousel-control-prev " type="button" data-bs-target="#carouselExample" data-bs-slide="prev" >
    <span className="carousel-control-prev-icon" aria-hidden="true" ></span>
    <span className="visually-hidden">Previous</span>
  </button>
  </div>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div>
    

    </>
} 
export default Silder;