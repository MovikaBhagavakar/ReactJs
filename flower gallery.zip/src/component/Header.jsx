import React from "react";
import "./css/header.css"

export default function Header(){
    return <>
   
 
 
   <i className="fa-regular fa-flower-tulip"></i>
    <h1 className="flower">Flower Gallery</h1>
    <i class="fa-solid fa-flower-tulip"></i>    </>
}
