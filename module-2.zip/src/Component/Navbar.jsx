import React from "react";
import './Css/navbar.css';
export default function Navbar(){
    return<>
      <nav className="container">
        <ul className="lists">
            <li className="list1" >Home</li>
            <li className="list">News</li>
            <li className="list">Sport</li>
            <li className="list">Reel</li>
            <li className="list">Travel</li>
            <li className="list">Future</li>
            <li className="list">Culture</li>
            <li className="list">Sound</li>
            <li className="list">Wether</li>
        </ul>

        
      </nav>
      <form  className="find" >
            <div className="find" >
            <input className="search" type="text" placeholder="Search Here" id="text" ></input>
           <i className="fa-solid fa-magnifying-glass glass "></i>
      
            </div>
        </form>
    </>
}