import React from "react";
import IMg1 from "./Images/bg2.jpg";
import "./Css/Signup.css";
import Detail from "./Detail";
import Cbutton from "./Cbutton";



export default function Signup() {
  return (
    <>
      <div className="flex">
        <div className="group">
          <div className="fcontainer">
            <span className="slide" style={{ "--wave": 1 }}>
              R
            </span>
            <span className="slide" style={{ "--wave": 2 }}>
              F
            </span>
            <span className="slide" style={{ "--wave": 3 }}>
              T
            </span>
            <span className="slide" style={{ "--wave": 4 }}>
              E
            </span>
            <span className="slide" style={{ "--wave": 5 }}>
              S
            </span>
          </div>

          <div className="sign">
            <p>Register with The RFTES</p>
         
          </div>
          <Detail/>
    <Cbutton/>
         
       
        </div>
     
        <div>
          <img className="img" src={IMg1} alt="this pic was hidden"></img>
        </div>
      </div>
    </>
  );
}
