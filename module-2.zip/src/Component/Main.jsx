import React from "react";
import './Css/main.css'
// import news from './Images/bg1.jpg';

export default function Main(props) {

    var a = new Date();

    //  var b=a.getDate()+(a.getMonth()+1)
    var dt = a.toDateString()

    return (
        <>
            <div className="date">
                <h2 className="wel">{props.title}</h2>
                <h2 className="dt">{dt}</h2>

            </div>
             
            
                
             
        </>
    )
}