import React from "react";
import './Css/detail.css';


export default function Detail(){
    return <>

    <div>
        <p className="date">
            What's your date of birth?
        </p>
        <div className="line">
            <input type="text" placeholder="Day" className="birth"></input>
            <input type="text" placeholder="Month" className="birth"></input>
            <input type="text" placeholder="Year" className="birth"></input>
        </div>
    </div>
    </>
}