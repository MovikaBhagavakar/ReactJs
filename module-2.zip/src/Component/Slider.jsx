import React,{useState} from "react";
import bg4 from './Images/bg1.jpg'
import bg1 from './Images/bg2.jpg';
import bg2 from './Images/bg3.jpg';
import bg3 from './Images/bg4.jpg';
import './Css/slide.css';

export default function Slider() {

   
    const[selectImage, setSelectImage]=useState(0)
    const[allImages, setAllImages]=useState([bg4,bg1,bg2,bg3]);

    return<>
   
    
      
    
         <div className="slide">
            <img src={allImages[selectImage]} className="sliding" alt=" "></img>
           </div>
           <div className="btn">
            <div>
       <button  onClick={() =>{
            if(selectImage >0)
            setSelectImage(selectImage-1)
           }}><p className="prev">&lt;</p></button>
           </div>
           <div>
            <button onClick={() =>{
            if(selectImage<allImages.length-1)
            setSelectImage(selectImage+1)
           }}><p  className="next">&gt;</p></button>
           </div>
           </div> 
           </>
    
    
}