import React from 'react';
import './Css/continue.css'

export default function Cbutton(){
    return<>
    <div className="next">
        <button className="continue">Continue</button>
    </div>
    </>
}