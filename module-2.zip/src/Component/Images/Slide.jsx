import { useState } from "react";
import React from "react";
import first from './image/First.jpg'
import Second from './image/Second.jpg'
import Third from './image/Third.jpg'

export default function Slide(){
    const[selectedImage ,setSelectedImage]=useState(0)
    const[allImage,setAllImage]=useState([first, Second, Third])

    return<>
    <div>
        <img width={200} height={200}   src={allImage[selectedImage]} alt=""></img>
        <button onClick={()=>{
            setSelectedImage(selectedImage+1)

        }}>Next</button>
        <button onClick={()=>{
            setSelectedImage(selectedImage-1)

        }}>prev</button>
    </div>
    </>

}