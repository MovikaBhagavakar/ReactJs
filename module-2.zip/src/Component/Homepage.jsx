import React from "react";
import './Css/Home.css'
import Navbar from "./Navbar";



export default function Homepage() {


    return <>
        <div className="clr">
            <div className="container1">
                <div className="rftes">
                    <span className="abc"   style={{'--light':1}}>R</span>
                    <span className=" abc"  style={{'--light':2}}>F</span>
                    <span className="abc" style={{'--light':3}}>T</span>
                    <span className="  abc" style={{'--light':4}}>E</span>
                    <span className=" abc"  style={{'--light':5}}>S</span>
                </div>
                <div>
                    <i className="fa-solid fa-user user"></i>

                </div>
                <p className="login">Log in</p>



                <Navbar></Navbar>
            </div>
        </div>




    </>

}