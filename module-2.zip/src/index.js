import React from 'react';
import ReactDOM from 'react-dom/client';


// import Signup from './Component/Signup';
import Homepage from './Component/Homepage';
import Main from './Component/Main';
// import News from './Component/News';
import Slider from './Component/Slider';
// import news from './Component/Images/bg1.jpg';







const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
  <>
  {/* <Signup/> */}

 

  <Homepage/> 
  <Main title="Welcome to RFTES.com" />
  <Slider/>

  {/* {/* <News value={news} />
  <News value={news}/> */}

  </>
 
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

