var password=document.getElementById("password");
var cpass=document.getElementById("confirm");


password.onclick=()=>{

    if(password.value===""){
        document.getElementById("demo3").innerHTML="Enter your password"

    }
    else{
        document.getElementById("demo3").innerHTML=""
    }


}
password.onkeyup=()=>{
    if(password.value===""){
        document.getElementById("demo3").innerHTML="Enter your password"

    }
    else if((password.value.length<8)){
        document.getElementById("demo3").innerHTML="Your password must be at least 8 characters"

    }
    else if(!(password.value.match(/[A-Z]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a Upper Number"
    }
    else if(!(password.value.match(/[a-z]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a lower Number"
    }
    else if(!(password.value.match(/[0-9]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a numeric Number"
    }
    else if(!(password.value.match(/[!\@\#\$\%\^\&\*\+\-\||\~\"\:\?\>\/\,)]/))){
        document.getElementById("demo3").innerHTML="one speical charter requird"
    }
    else{
        document.getElementById("demo3").innerHTML=""
    }
}
cpass.onclick=()=>{

    if(cpass.value===""){
        document.getElementById("demo4").innerHTML="Enter your password"

    }
    else{
        document.getElementById("demo4").innerHTML=""
    }


}
cpass.onkeyup=()=>{

    if(cpass.value===""){
        document.getElementById("demo4").innerHTML="Enter your password"

    }
    else if(cpass.value!==password.value){
        document.getElementById("demo4").innerHTML="Your password must be wrong"
    }
    else{
        document.getElementById("demo4").innerHTML=""
    }


}