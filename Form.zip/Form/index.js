var fname=document.getElementById("fname");
var lname=document.getElementById("lname");
var email=document.getElementById("email");
var password=document.getElementById("password");
var cpass=document.getElementById("confirm");
var phone=document.getElementById("phone");
 
fname.onclick=function(){
 
    if(fname.value===""){
        document.getElementById("demo").innerHTML="Enter a value"
        return false;
    }
    else{
        document.getElementById("demo").innerHTML=" ";
    }
}

fname.onkeyup=function(){
    if(fname.value===""){
        document.getElementById("demo").innerHTML="Enter a value"
        return false;
    }
    else if(!(fname.value.match(/^[a-zA-Z]*$/))){
        document.getElementById("demo").innerHTML="Plese Enter Correct Name"
        
    }
    else{
        document.getElementById("demo").innerHTML=" ";
    }
}

lname.onclick=function (){
    if(lname.value===""){
        document.getElementById("demo1").innerHTML="Enter a value"
    }
    else if(fname.value.length>10){
        document.getElementById("demo1").innerHTML="your name is too long"
    }
    else{
        document.getElementById("demo1").innerHTML=" ";
    }
}
lname.onkeyup=function (){
    if(lname.value===""){
        document.getElementById("demo1").innerHTML="Enter a value"
    }
    else if(!(lname.value.match(/^[a-zA-Z]*$/))){
        document.getElementById("demo1").innerHTML="Plese Enter Correct Name"
        
    }
    else if(lname.value.length>10){
        document.getElementById("demo1").innerHTML="your name is too long"
    }
    else{
        document.getElementById("demo1").innerHTML=" ";
    }
}
phone.onclick=()=>{
    if(phone.value===""){
        document.getElementById("call").innerHTML="Enter Your Phone number";
    }
    else{
        document.getElementById("call").innerHTML="";
    }
}
phone.onkeyup=()=>{
    if(phone.value===""){
        document.getElementById("call").innerHTML="Enter Your Phone number";
    }
    else if(phone.value.length!==10 || phone.value.length>10){
        document.getElementById("call").innerHTML="Your length must be 10"
    }
    else{
        document.getElementById("call").innerHTML="";
    }

}
email.onclick=()=>{
    if(email.value===""){
        document.getElementById("demo2").innerHTML="Enter a email"

    }
    else{
        document.getElementById("demo2").innerHTML=" "

    }
}
email.onkeyup=()=>{
    if(email.value===""){
        document.getElementById("demo2").innerHTML="Enter a email"

    }
    else if(!(email.value.match(/^[a-z\._\-0-9]*[@][a-z]*[\.][a-z]{2,4}/))){
        document.getElementById("demo2").innerHTML="Please Enter your Correct email id"

    }
    else{
        document.getElementById("demo2").innerHTML=" "

    }

}
password.onclick=()=>{

    if(password.value===""){
        document.getElementById("demo3").innerHTML="Enter your password"

    }
    else{
        document.getElementById("demo3").innerHTML=""
    }


}
password.onkeyup=()=>{
    if(password.value===""){
        document.getElementById("demo3").innerHTML="Enter your password"

    }
    else if((password.value.length<8)){
        document.getElementById("demo3").innerHTML="Your password must be at least 8 characters"

    }
    else if(!(password.value.match(/[A-Z]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a Upper Number"
    }
    else if(!(password.value.match(/[a-z]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a lower Number"
    }
    else if(!(password.value.match(/[0-9]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a numeric Number"
    }
    else if(!(password.value.match(/[!\@\#\$\%\^\&\*\+\-\||\~\"\:\?\>\/\,)]/))){
        document.getElementById("demo3").innerHTML="one speical charter requird"
    }
    else{
        document.getElementById("demo3").innerHTML=""
    }
}
cpass.onclick=()=>{

    if(cpass.value===""){
        document.getElementById("demo4").innerHTML="Enter your password"

    }
    else{
        document.getElementById("demo4").innerHTML=""
    }


}
cpass.onkeyup=()=>{

    if(cpass.value===""){
        document.getElementById("demo4").innerHTML="Enter your password"

    }
    else if(cpass.value!==password.value){
        document.getElementById("demo4").innerHTML="Your password must be wrong"
    }
    else{
        document.getElementById("demo4").innerHTML=""
    }


}

 
 



function valid(){
    if(fname.value===""||lname.value===""||email.value===""||password.value===""||cpass.value===""){
        alert("Please enter Your value")
      
    }
   
    else{
        window.location="http://127.0.0.1:5500/Form/Login.html"
        alert("Successfully Register")
        window.location.href="Login.html"
        return false;
      
    }
}
