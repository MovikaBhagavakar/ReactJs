var email=document.getElementById("email");
var password=document.getElementById("password");

email.onclick=()=>{
    if(email.value===""){
        document.getElementById("demo2").innerHTML="Enter a email"

    }
    
    else{
        document.getElementById("demo2").innerHTML=style.borderColor='Black'+"";

    }
}
email.onkeyup=()=>{
    if(email.value===""){
        document.getElementById("demo2").innerHTML="Enter a email"

    }
    else if(!(email.value.match(/^[a-z\._\-0-9]*[@][a-z]*[\.][a-z]{2,4}/))){
        document.getElementById("demo2").innerHTML="Please Enter your Correct email id"

    }
    else{
        document.getElementById("demo2").innerHTML=" "

    }

}
password.onclick=()=>{

    if(password.value===""){
        document.getElementById("demo3").innerHTML="Enter your password"

    }
    else{
        document.getElementById("demo3").innerHTML=""
    }


}
password.onkeyup=()=>{
    if(password.value===""){
        document.getElementById("demo3").innerHTML="Enter your password"

    }
    else if((password.value.length<8)){
        document.getElementById("demo3").innerHTML="Your password must be at least 8 characters"

    }
    else if(!(password.value.match(/[A-Z]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a Upper Number"
    }
    else if(!(password.value.match(/[a-z]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a lower Number"
    }
    else if(!(password.value.match(/[0-9]/))){
        document.getElementById("demo3").innerHTML="please One letter should be a numeric Number"
    }
    else if(!(password.value.match(/[!\@\#\$\%\^\&\*\+\-\||\~\"\:\?\>\/\,)]/))){
        document.getElementById("demo3").innerHTML="one speical charter requird"
    }
    else{
        document.getElementById("demo3").innerHTML=""
    }
}
function valid(){
    window.location.href="SIgnup.html"
    return false;
}

function sub(){
    if(email.value===""||password.value===""){
        alert("Invalid credentials")
        return false;

    }
    else{
        alert("Welcome!! You Are login Successfully")
    }
}